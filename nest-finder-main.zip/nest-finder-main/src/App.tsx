import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Listings from "./pages/Listings";
import PropertyDetail from "./pages/PropertyDetail";
import Wishlist from "./pages/Wishlist";
import Login from "./pages/Login";
import Signup from "./pages/Signup";
import Dashboard from "./pages/Dashboard";
import Playgrounds from "./pages/Playgrounds";
import PlaygroundDetail from "./pages/PlaygroundDetail";
import MyPlaygroundBookings from "./pages/MyPlaygroundBookings";
import AdminPanel from "./pages/AdminPanel";
import SubmitProperty from "./pages/SubmitProperty";
import NotFound from "./pages/NotFound";
import HomiiiAI from "./components/HomiiiAI";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/listings" element={<Listings />} />
          <Route path="/property/:id" element={<PropertyDetail />} />
          <Route path="/wishlist" element={<Wishlist />} />
          <Route path="/login" element={<Login />} />
          <Route path="/signup" element={<Signup />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/playgrounds" element={<Playgrounds />} />
          <Route path="/playgrounds/:id" element={<PlaygroundDetail />} />
          <Route path="/playgrounds/my-bookings" element={<MyPlaygroundBookings />} />
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="/submit-property" element={<SubmitProperty />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        <HomiiiAI />
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
